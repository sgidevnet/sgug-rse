Errors
======

.. toctree::
   :maxdepth: 3

.. automodule:: string_utils.errors
   :members:
   :undoc-members:
   :show-inheritance:
