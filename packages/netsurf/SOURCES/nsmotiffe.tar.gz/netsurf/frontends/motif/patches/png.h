#include "/usr/sgug/include/png.h"

