# Universal Packaging Tool: CPAN frontend
This is a [CPAN](https://www.cpan.org/) frontend for [upt](https://pypi.python.org/pypi/upt).
